# Technical Report — Moved

**Status:** NOT ATTEMPTED. The canonical blank report is [technical_interview/score_report.md](../technical_interview/score_report.md). Do not enter results in this compatibility page.

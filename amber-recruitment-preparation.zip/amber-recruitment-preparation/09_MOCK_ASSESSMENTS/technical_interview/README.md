# Mode B — Technical Interview

**Updated:** 1 November 2026

Use [instructions](instructions.md), then the [timed script](interviewer_script.md). The script names exact tasks and follow-ups; answer references are separated so they do not leak during the attempt. Record observed results in [score_report.md](score_report.md).

No assessor is available? Read one prompt, close the page and speak/solve on paper, recording your own practice if desired. Compare afterwards. A self-assessed explanation is weaker evidence than independently verified work; state that condition in the report.

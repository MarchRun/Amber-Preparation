# Mode B — Technical Interview and Work Sample

**Created:** 31 October 2026
**Last updated:** 1 November 2026 — canonical technical-interview location.
**Purpose:** Test explanation, SQL and a small algorithm without inventing assessment content.

45-minute original practice:

- 0–8: explain value/reference, authentication/authorization and idempotency. Follow with one counterexample each.
- 8–20: use the section 05 SQL schema. Write queries 4, 8, 12 and 15 without viewing solutions. Explain zero-row and tie behaviour.
- 20–35: implement two sum or a sliding-window sum in the preferred language. Clarify input/invalid cases; give complexity and tests.
- 35–45: diagnose a duplicate-event or missing-report-row scenario from `../../05_TECHNICAL_PREPARATION/debugging_and_testing.md`.

Allow documentation only if this is explicitly an open-reference rehearsal; record that condition. Keep hints separate from independent answers. Evaluator asks "why?" and "what fails?", not obscure framework trivia.

Score in `score_report.md`. Correctness must be assessed from the actual artifact; a fluent explanation does not make wrong SQL correct.

# Mode C — Business Case

**Created:** 31 October 2026
**Last updated:** 1 November 2026 — canonical programmer-business-case location.
**Purpose:** Produce and defend a right-sized solution.

Choose one fictional case in `../../06_BUSINESS_CASES/case_studies/`. Read only its candidate brief before starting. A facilitator can copy that brief to a clean page so the worked answer stays hidden.

45 minutes: 5 clarify; 3 scope; 15 design; 7 risks/tests/trade-offs; 10 prepare; 5 present. One-page memo plus one diagram. Use English for the spoken answer.

After presentation, facilitator changes one assumption: unreliable connectivity, stricter tenant separation or no supported ERP API. Give three minutes to revise. These are original follow-ups, not Amber questions.

Score using `../../06_BUSINESS_CASES/solution_evaluations/evaluation_rubric.md` and copy observations into `score_report.md`. A new requirement should change the relevant design, not trigger a defensive claim that everything was already handled.

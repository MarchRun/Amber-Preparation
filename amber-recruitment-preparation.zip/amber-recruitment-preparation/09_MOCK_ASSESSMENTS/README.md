# Mock Assessments — Modes A–F

**Purpose:** Generate observed evidence, not predicted hiring scores.
**Created:** 31 October 2026
**Last updated:** 1 November 2026
**Status:** Original practice formats. Amber's actual agenda, rubric and pass threshold are UNKNOWN. No live attempt has occurred.

| Mode | Instructions | Duration | Output |
|---|---|---:|---|
| A | `ccat/instructions.md` | 15 + 20 review | Raw score, method/guess split, error log |
| B | `technical_interview/instructions.md` | 45 + 10 review | Code/query/explanation evidence |
| C | `programmer_business_case/instructions.md` | 45 + 10 review | Memo, diagram, spoken solution |
| D | `english_interview/instructions.md` | 25 + 10 review | Recording and comprehension observations |
| E | `hr/instructions.md` | 25 + 10 review | Honest motivation and incident answers |
| F | `full_simulation/instructions.md` | 270 including review/breaks | Integrated stamina/logistics rehearsal |

With one preparation day remaining on 1 November, A + C + D is more useful than spending all day reading. Full mode is optional and expensive; prefer a 90-minute combined rehearsal if tired. See `evaluation_reports/README.md` for the canonical result locations and a fictional worked scoring example. Old technical/business_case/english folders are compatibility routes, not additional material or extra mock modes.

**Facilitator rule:** Ask one question at a time; do not reveal model answers before response; time attempts strictly; distinguish hint-assisted results. No outside help during cognitive mocks. Follow actual employer instructions during the real assessment; this folder does not authorise notes, calculators, AI, recording or extra screens.

Record only your practice answers. Never record a real interview or retain confidential employer questions without permission.

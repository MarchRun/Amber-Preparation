# Technical Mock — Moved

Use [technical_interview/instructions.md](../technical_interview/instructions.md) and the [ready-to-run interview script](../technical_interview/interviewer_script.md). This is a compatibility page, not another mock mode.

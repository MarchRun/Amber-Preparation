# Ready-to-Run Technical Script

**Created:** 1 November 2026
**Status:** Original practice, not Amber's questions. Forty-five minutes plus ten-minute review.

## Candidate instructions

Use English. Explain assumptions and ask a precise clarification if needed. Preferred language is allowed for this mock; that does not establish the real assessment's language policy. No answer key during the timed work. Mark any hint or documentation use.

## Timed prompts — facilitator reads one at a time

| Minutes | Exact prompt | Follow-up |
|---|---|---|
| 0–3 | Explain copying an object reference versus copying an object in JavaScript. | Does reassigning a function parameter change the caller's variable? |
| 3–5 | Explain authentication versus authorization for a mentor editing attendance. | What check is needed beyond the role name? |
| 5–8 | What does idempotency mean? | Can response codes differ while the effect remains idempotent? |
| 8–11 | With departments and employees, list every department and headcount, including zero. | Why COUNT(employee_id), not COUNT(*)? |
| 11–14 | Find employees paid above their department average. | What happens to an unassigned employee? |
| 14–17 | Show headcount and project budget per department without inflating either. | What happens with two employees and three projects? |
| 17–20 | Return the second distinct highest salary. | Define the result when no second salary exists. |
| 20–35 | Given an integer list and target, return two distinct indices whose values sum to target, or no result. | Test [3,3] targeting 6; a match at index zero; empty input; no match. Explain time and extra space. |
| 35–40 | Two retry requests create duplicate attendance. Diagnose the likely boundary and propose a correction. | What observation would disprove the first hypothesis? |
| 40–45 | A stock count check succeeds twice for the final unit. How would you prevent this? | Why is a plain read-then-write inside a transaction not necessarily enough? |

SQL schema is the practice schema in [SQL guide](../../05_TECHNICAL_PREPARATION/sql_and_databases.md). Show only schema/seed section during the attempt, not query solutions. This drill assumes PostgreSQL; if writing another dialect, identify the differences.

## Assessor notes — open only afterwards

- Fundamentals: parameter values are copied, object references can alias; server-side object/assignment permission is required; idempotency concerns intended effect, not identical response.
- SQL tasks correspond to guide queries 4, 8, 12 and 15. Independently check nulls, zero departments and join multiplication. Expected seed checks: Engineering 2/Operations 1/Finance 0; Bela above department average; second distinct salary 8,000,000 before mutations.
- Two sum: hash map of prior values gives expected O(n) time/O(n) space. It must not reuse one element. A correct O(n²) approach is still correct; ask whether optimisation is needed instead of penalising honesty.
- Duplicate attendance: reproduce, inspect stable event identity and business uniqueness, coordinate durable deduplication and attendance write. A browser-only check fails under retries/concurrency.
- Stock: guarded update or appropriate locking, affected-row check and consistent order/ledger transaction; concurrency test must show only one success.

## Ten-minute review

Record independently correct artifacts, not just fluent phrases. Choose the two highest-impact mistakes and re-solve them without the key. Use [the report](score_report.md) and [central evidence instructions](../evaluation_reports/README.md). No total here predicts hiring success.

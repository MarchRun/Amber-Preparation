# Mode C — Programmer Business Case

**Updated:** 1 November 2026

1. Open [candidate_brief.md](candidate_brief.md) only, and set 45 minutes.
2. Follow [instructions.md](instructions.md). Produce one-page memo and diagram, then speak in English.
3. Afterwards compare with [the worked school case](../../06_BUSINESS_CASES/case_studies/case_1_school_management.md), [architecture](../../06_BUSINESS_CASES/system_design/architecture_walkthroughs.md) and [rubric](../../06_BUSINESS_CASES/solution_evaluations/evaluation_rubric.md).
4. Record observed evidence in [score_report.md](score_report.md).

No file in this folder contains Amber's actual case or cut-off. Different designs can be reasonable if their assumptions, invariants and costs are defensible.
